SolidCAM STL Exporter 1.2.0

1. Close SOLIDWORKS.
2. Copy this folder to a permanent place, for example C:\Tools\SolidCamStlExporter.
3. Double-click Install.exe and allow it to make changes (or right-click install.cmd and choose Run as administrator).
4. Start SOLIDWORKS, open the SolidCAM Automation tab and click Machine Simulation Builder.
   If the tab is missing, turn on the add-in in Tools > Add-Ins.

Later versions are offered automatically inside the add-in.
