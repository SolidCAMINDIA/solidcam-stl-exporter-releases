@echo off
setlocal
rem Registers the SolidCAM STL Exporter add-in. Close SOLIDWORKS first.
rem Easiest: double-click Install.exe. This script does the same and asks for administrator rights itself.
rem install.cmd /quiet is used by the automatic update and does not pause.

set "PAUSE=pause"
if /i "%~1"=="/quiet" set "PAUSE=rem"
set "HERE=%~dp0"
set "SELF=%~f0"
set "LOG=%~dp0install.log"
cd /d "%HERE%"
echo SolidCAM STL Exporter install.cmd %DATE% %TIME%> "%LOG%" 2>nul

net session >nul 2>&1
if not errorlevel 1 goto :admin
if /i "%~1"=="/quiet" goto :notadmin
echo Asking Windows for administrator rights...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:SELF -Verb RunAs" >nul 2>&1
if errorlevel 1 goto :notadmin
exit /b 0

:notadmin
echo Administrator rights are needed.
echo Double-click Install.exe, or right-click install.cmd and choose Run as administrator.
%PAUSE%
exit /b 1

:admin
if exist "%HERE%bin\ScStl.AddIn.dll" goto :havedll
echo bin\ScStl.AddIn.dll was not found next to install.cmd.
echo If you opened the zip in Explorer, extract it first: right-click the zip, choose Extract All,
echo and run Install.exe or install.cmd from the extracted folder.
>>"%LOG%" 2>nul echo bin\ScStl.AddIn.dll not found in %HERE%
%PAUSE%
exit /b 1

:havedll
rem Files unzipped from a download are marked as coming from the internet, and .NET will not load them.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:HERE -Recurse | Unblock-File" >nul 2>&1

rem The SOLIDWORKS API files come from the local SOLIDWORKS installation when they are missing.
if exist "%HERE%bin\SolidWorks.Interop.sldworks.dll" goto :haveinterop
for /d %%D in ("%ProgramFiles%\SOLIDWORKS Corp\SOLIDWORKS*") do if exist "%%~D\api\redist\SolidWorks.Interop.sldworks.dll" copy /y "%%~D\api\redist\SolidWorks.Interop.*.dll" "%HERE%bin\" >nul
if exist "%HERE%bin\SolidWorks.Interop.sldworks.dll" goto :haveinterop
echo SOLIDWORKS API files not found. Copy SolidWorks.Interop.*.dll from SOLIDWORKS\api\redist into the bin folder.
%PAUSE%
exit /b 1

:haveinterop
set "REGASM=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
if exist "%REGASM%" goto :register
echo The 64-bit .NET Framework 4 RegAsm.exe was not found: %REGASM%
%PAUSE%
exit /b 1

:register
"%REGASM%" /codebase /nologo "%HERE%bin\ScStl.AddIn.dll" >>"%LOG%" 2>&1
if errorlevel 1 goto :failed
>>"%LOG%" 2>nul echo Installed.
echo SolidCAM STL Exporter is installed. Start SOLIDWORKS.
echo Open the SolidCAM Automation tab and click Machine Simulation Builder.
echo If the tab is missing, turn on the add-in in Tools ^> Add-Ins.
%PAUSE%
exit /b 0

:failed
echo Registration failed:
type "%LOG%"
%PAUSE%
exit /b 1
