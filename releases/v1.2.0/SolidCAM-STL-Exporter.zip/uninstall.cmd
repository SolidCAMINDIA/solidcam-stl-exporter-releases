@echo off
setlocal
rem Removes the add-in registration. Close SOLIDWORKS first.
rem Easiest: double-click Uninstall.exe. This script does the same and asks for administrator rights itself.

set "HERE=%~dp0"
set "SELF=%~f0"
cd /d "%HERE%"

net session >nul 2>&1
if not errorlevel 1 goto :admin
echo Asking Windows for administrator rights...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:SELF -Verb RunAs" >nul 2>&1
if errorlevel 1 goto :notadmin
exit /b 0

:notadmin
echo Administrator rights are needed. Double-click Uninstall.exe, or right-click uninstall.cmd and choose Run as administrator.
pause
exit /b 1

:admin
"%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe" /unregister /nologo "%HERE%bin\ScStl.AddIn.dll"
pause
