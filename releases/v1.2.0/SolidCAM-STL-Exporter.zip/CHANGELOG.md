# Changelog

## Release workflow - 2026-11-21
- Stable tags vX.Y.Z also publish to the public releases repository (zip first, download checked, then latest.xml), so users get the update prompt. Tags with a hyphen stay private pre-releases.
- The workflow fails if the tag does not match src/AddIn/Version.cs and the built DLL version.
- Manual runs can be a dry run, or publish to a test repository.
- latest.xml and its SHA-256 come from tools/release-manifest.ps1, shared with release.ps1.

## 1.2.0 (preview 4) - 2026-11-21
- New SOLIDWORKS CommandManager tab "SolidCAM Automation" (assemblies and parts) with the button "Machine Simulation Builder" and an RGB axis triad icon. The task pane tab is gone.
- The button opens the Machine Simulation Builder: a resizable, modeless window owned by SOLIDWORKS (one at a time; closing hides it and keeps its state). Flat Windows layout: VMID toolbar, Geometry / Machine axes / Export & Simulation panes with splitters, collapsible Output Log, status bar with progress and Check for updates.
- Add axis moved from a button to the right-click menu of Machine base.
- All actions still run the existing export engine: assignments, dialogs, preview, ModuleWorks, external STL, VMID reload and SOLIDWORKS selection sync behave as before.
- build.cmd takes an optional Release or Debug argument; the release workflow builds both.

## 1.2.0 (preview 3) - 2026-11-21
- New Install.exe and Uninstall.exe: double-click, allow the change, and a message shows the result. They do not need cmd or PowerShell, so they also work where scripts are blocked, and they write install.log.
- install.cmd asks for administrator rights itself, says so when it is run from inside the zip, works in folders whose name contains brackets, and writes install.log.

## 1.2.0 (preview 2) - 2026-11-21
- The new WPF view now works: it replaces the preview tab and is the default view of the SolidCAM STL Exporter tab. It shows and drives the classic panel, so every button, dialog, setting, right-click menu and the SOLIDWORKS selection sync behave as before.
- "Classic view" at the bottom switches to the classic panel; "Switch to the new view" switches back. Both show the same state.
- Right-click a geometry row for the axis list, right-click a machine row for its menu, double-click a transform to edit it. Rows selected in SOLIDWORKS are highlighted yellow.

## 1.2.0 (preview) - 2026-11-21
- New WPF task pane design (Fluent, card-based light theme) in a second tab, "SolidCAM STL Exporter (new UI preview)". It runs on sample data so the layout can be reviewed in SOLIDWORKS; the classic tab still does the work.
- New files: src/UI/Wpf/Styles.xaml, StlExporterControl.xaml, StlExporterViewModel.cs, StlExporterView.cs. The XAML is embedded in the DLL and loaded at runtime, so build.cmd still needs no Visual Studio.
- Release workflow: tags with a "-" (for example v1.2.0-beta.1) are published as pre-releases, a manual run can create the tag, and each build renders a screenshot of the new UI.

## 1.1.1 - 2026-11-21
- Fixed "Could not load the VMID: Method not found String.TrimStart" in 1.1.0.
- install.cmd unblocks downloaded files before registering.

## 1.1.0 - 2026-11-21
- Checks for a new version when SOLIDWORKS starts (at most once a day) and offers to update. "Check for updates" link at the bottom of the panel.
- Update now downloads the new version, checks it and installs it when SOLIDWORKS closes.
- Open VMID and Reload VMID buttons; Clear Selection.
- Axis vectors and rotation points shown and editable in the preview, saved to the VMID and the machine XML.
- External STL transforms (for example SolidCAMLogo), placed by values, a coordinate system, face + point or three points.
- Fixed the "workpiece virtual transformation" error in created machine XML files.

## 1.0.0
- First version: VMID axes, geometry assignment, STL export, machine simulation XML, preview, ModuleWorks launch.
