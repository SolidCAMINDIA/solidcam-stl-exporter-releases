@echo off
setlocal
rem Removes the add-in registration. Run as administrator with SOLIDWORKS closed.

net session >nul 2>&1
if errorlevel 1 (
  echo Please right-click uninstall.cmd and choose Run as administrator.
  pause
  exit /b 1
)

cd /d "%~dp0"
"%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe" /unregister /nologo bin\ScStl.AddIn.dll
pause
