SolidCAM STL Exporter 1.1.0

1. Close SOLIDWORKS.
2. Copy this folder to a permanent place, for example C:\Tools\SolidCamStlExporter.
3. Right-click install.cmd and choose Run as administrator.
4. Start SOLIDWORKS and turn on the add-in in Tools > Add-Ins.

Later versions are offered automatically inside the add-in.
