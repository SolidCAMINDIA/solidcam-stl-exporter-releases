@echo off
setlocal
rem Registers the add-in. Run as administrator with SOLIDWORKS closed.
rem install.cmd /quiet is used by the automatic update and does not pause.

set "PAUSE=pause"
if /i "%~1"=="/quiet" set "PAUSE=rem"

net session >nul 2>&1
if errorlevel 1 (
  echo Please right-click install.cmd and choose Run as administrator.
  %PAUSE%
  exit /b 1
)

cd /d "%~dp0"
if not exist bin\ScStl.AddIn.dll (
  echo bin\ScStl.AddIn.dll not found. Run build.cmd first.
  %PAUSE%
  exit /b 1
)

rem The SOLIDWORKS API files come from the local SOLIDWORKS installation when they are missing.
if not exist bin\SolidWorks.Interop.sldworks.dll (
  for /d %%D in ("%ProgramFiles%\SOLIDWORKS Corp\SOLIDWORKS*") do (
    if exist "%%D\api\redist\SolidWorks.Interop.sldworks.dll" (
      copy /y "%%D\api\redist\SolidWorks.Interop.sldworks.dll" bin >nul
      copy /y "%%D\api\redist\SolidWorks.Interop.swconst.dll" bin >nul
      copy /y "%%D\api\redist\SolidWorks.Interop.swpublished.dll" bin >nul
    )
  )
)
if not exist bin\SolidWorks.Interop.sldworks.dll (
  echo SOLIDWORKS API files not found. Copy SolidWorks.Interop.*.dll from SOLIDWORKS\api\redist into the bin folder.
  %PAUSE%
  exit /b 1
)

"%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe" /codebase /nologo bin\ScStl.AddIn.dll
if errorlevel 1 (
  echo Registration failed.
  %PAUSE%
  exit /b 1
)
echo SolidCAM STL Exporter is installed. Start SOLIDWORKS.
%PAUSE%
exit /b 0
